"""
lockguard.py — Merged Engine: Deadlock Detection, Priority Tracking, and Aging/Fairness
"""

import os
import sys
import time
import threading
from dataclasses import dataclass, field

# ---- OS Priority Helpers (Aging & Boosting) ----

def get_native_thread_id():
    """Returns kernel Thread ID (TID) on Linux/Posix systems."""
    if hasattr(os, 'gettid'):
        return os.gettid()
    try:
        import ctypes
        SYS_gettid = 186 if os.uname().machine == 'x86_64' else 224
        return ctypes.CDLL(None).syscall(SYS_gettid)
    except Exception:
        return threading.get_ident()

def set_os_niceness(tid: int, priority: int):
    """
    Attempts to set native thread niceness via os.setpriority.
    Maps priority scale (e.g. 1-100) to Linux niceness (-20 to 19).
    """
    if sys.platform.startswith("linux") and hasattr(os, "setpriority"):
        try:
            # High priority (100) -> Nice -20; Low priority (1) -> Nice 19
            nice_val = max(-20, min(19, int(19 - (priority / 100.0) * 39)))
            os.setpriority(os.PRIO_PROCESS, tid, nice_val)
            return True
        except PermissionError:
            pass  # Requires elevated privileges/CAP_SYS_NICE
        except Exception:
            pass
    return False


@dataclass
class LockState:
    name: str
    owner: str = None          # thread name currently holding it
    waiters: set = field(default_factory=set)


class InstrumentedLock:
    """Standard Lock wrapper used for Deadlock detection & basic tracking."""

    def __init__(self, name, guard):
        self.name = name
        self._lock = threading.Lock()
        self.guard = guard
        guard.register_lock(name)

    def acquire(self, thread_name):
        self.guard.mark_waiting(thread_name, self.name)
        self._lock.acquire()  # Real OS-level block
        self.guard.mark_acquired(thread_name, self.name)

    def release(self, thread_name):
        try:
            self._lock.release()
        except RuntimeError:
            pass  # Handles force-release recovery from deadlock
        self.guard.mark_released(thread_name, self.name)


class PriorityInheritingLock:
    """
    Advanced Lock wrapper supporting Priority Inheritance and Aging/Fairness.
    Prevents Priority Inversion and Starvation by dynamic priority boosting.
    """

    def __init__(self, name, guard):
        self.name = name
        self._lock = threading.Lock()
        self.guard = guard
        self.fairness_enabled = False
        guard.register_lock(name)

    def acquire(self, thread_name: str, priority: int = 50, tid: int = None):
        tid = tid or get_native_thread_id()
        self.guard.mark_waiting(thread_name, self.name, priority=priority, tid=tid)
        
        # Priority Inheritance / Aging Check
        self.guard.check_and_boost_owner(self.name, waiting_priority=priority)
        
        self._lock.acquire()
        self.guard.mark_acquired(thread_name, self.name, priority=priority, tid=tid)

    def release(self, thread_name: str):
        try:
            self._lock.release()
        except RuntimeError:
            pass
        self.guard.mark_released(thread_name, self.name)


class LockGuard:
    """
    Central Monitoring & Synchronization Engine:
    - Builds Wait-For Graphs and detects Deadlock Cycles (DFS).
    - Tracks Thread Priorities, Wait Durations, and performs Dynamic Aging.
    """

    def __init__(self):
        self._locks = {}                 # name -> LockState
        self._lock_owned_by_thread = {}  # thread_name -> set(lock_names)
        self._mutex = threading.Lock()   # Protects internal state
        self.trace = []
        self.wait_start_time = {}        # (thread, lock) -> timestamp
        
        # Priority & Aging tracking
        self.thread_priorities = {}      # thread_name -> current priority
        self.base_priorities = {}        # thread_name -> base priority
        self.thread_tids = {}            # thread_name -> OS tid

    # ---- Instrumentation Hooks ----

    def register_lock(self, name):
        with self._mutex:
            self._locks.setdefault(name, LockState(name))

    def mark_waiting(self, thread_name, lock_name, priority=50, tid=None):
        with self._mutex:
            self._locks[lock_name].waiters.add(thread_name)
            self.wait_start_time[(thread_name, lock_name)] = time.time()
            
            if thread_name not in self.base_priorities:
                self.base_priorities[thread_name] = priority
                self.thread_priorities[thread_name] = priority
            if tid:
                self.thread_tids[thread_name] = tid

            self._log("WAIT_ANALYSIS", f"{thread_name} (Prio: {priority}) -> {lock_name}")

    def mark_acquired(self, thread_name, lock_name, priority=50, tid=None):
        with self._mutex:
            state = self._locks[lock_name]
            state.owner = thread_name
            state.waiters.discard(thread_name)
            self._lock_owned_by_thread.setdefault(thread_name, set()).add(lock_name)
            self.wait_start_time.pop((thread_name, lock_name), None)
            
            if tid:
                self.thread_tids[thread_name] = tid
                
            self._log("RESOURCE_ANALYSIS", f"{lock_name} -> {thread_name}")

    def mark_released(self, thread_name, lock_name):
        with self._mutex:
            state = self._locks[lock_name]
            if state.owner == thread_name:
                state.owner = None
            self._lock_owned_by_thread.get(thread_name, set()).discard(lock_name)
            
            # Priority Restoration after releasing resource
            if thread_name in self.base_priorities:
                base = self.base_priorities[thread_name]
                if self.thread_priorities.get(thread_name) != base:
                    self.thread_priorities[thread_name] = base
                    tid = self.thread_tids.get(thread_name)
                    if tid:
                        set_os_niceness(tid, base)
                    self._log("PRIORITY_RESTORE", f"{thread_name} priority restored to {base}")

            self._log("RESOURCE_RELEASE", f"{lock_name} released by {thread_name}")

    def _log(self, event, detail):
        self.trace.append({"t": time.time(), "event": event, "detail": detail})

    # ---- Dynamic Aging & Priority Boosting (Starvation / Inversion Fix) ----

    def check_and_boost_owner(self, lock_name: str, waiting_priority: int):
        """Boosts the priority of the current lock owner if a waiting thread has higher priority (Aging/PI)."""
        with self._mutex:
            state = self._locks.get(lock_name)
            if not state or not state.owner:
                return

            owner = state.owner
            owner_prio = self.thread_priorities.get(owner, 50)

            if waiting_priority > owner_prio:
                self.thread_priorities[owner] = waiting_priority
                tid = self.thread_tids.get(owner)
                if tid:
                    set_os_niceness(tid, waiting_priority)
                self._log("PRIORITY_BOOST", f"Boosted {owner} priority from {owner_prio} to {waiting_priority} (Aging/PI on {lock_name})")

    # ---- Graph Analysis & Deadlock Cycle Detection ----

    def build_wait_for_graph(self):
        """Builds wait-for graph: thread -> set(threads holding requested locks)."""
        with self._mutex:
            graph = {}
            for lock_name, state in self._locks.items():
                if state.owner is None:
                    continue
                for waiter in state.waiters:
                    graph.setdefault(waiter, set()).add(state.owner)
            return graph

    def detect_cycle(self):
        """Classic DFS cycle detection algorithm on wait-for graph."""
        graph = self.build_wait_for_graph()
        visited, stack, path = set(), set(), []

        def dfs(node):
            visited.add(node)
            stack.add(node)
            path.append(node)
            for neighbor in graph.get(node, ()):
                if neighbor not in visited:
                    result = dfs(neighbor)
                    if result:
                        return result
                elif neighbor in stack:
                    cycle_start = path.index(neighbor)
                    return path[cycle_start:] + [neighbor]
            stack.discard(node)
            path.pop()
            return None

        for node in list(graph.keys()):
            if node not in visited:
                cycle = dfs(node)
                if cycle:
                    self._log("DETECTOR", f"Cycle found: {' -> '.join(cycle)}")
                    return cycle
        return None

    def waiting_durations(self):
        now = time.time()
        with self._mutex:
            return {f"{t}->{l}": round(now - ts, 3)
                    for (t, l), ts in self.wait_start_time.items()}

    def snapshot(self):
        return {
            "locks": {
                n: {
                    "owner": s.owner or "None",
                    "process": s.owner or "None",  # Prevents 'undefined' in frontend UI tables
                    "waiters": list(s.waiters)
                }
                for n, s in self._locks.items()
            },
            "wait_for_graph": {k: list(v) for k, v in self.build_wait_for_graph().items()},
            "cycle": self.detect_cycle(),
            "waiting_durations": self.waiting_durations(),
            "priorities": dict(self.thread_priorities)
        }

    def force_release(self, thread_name, lock_name):
        """Recovery action: forcibly break a cycle (simulates aborting a victim thread)."""
        self._log("RECOVERY", f"Recovery selected victim: {thread_name} on {lock_name}")
