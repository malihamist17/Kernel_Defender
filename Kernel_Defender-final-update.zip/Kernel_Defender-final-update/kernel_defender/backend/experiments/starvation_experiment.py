
import random
import threading
import time

from lockguard import LockGuard, InstrumentedLock, PriorityInheritingLock


class StarvationExperiment:
    def __init__(self, n_threads=4, duration_sec=6):
        self.guard = LockGuard()
        self.shared = InstrumentedLock("SharedResource", self.guard)
        self.n_threads = n_threads
        self.duration_sec = duration_sec
        self.service_count = {f"T{i}": 0 for i in range(n_threads)}
        self.wait_log = {f"T{i}": [] for i in range(n_threads)}
        self._stop = threading.Event()
        self.fair_mode = False  # toggled by "apply fairness fix" action

    def _worker(self, idx):
        name = f"T{idx}"
        while not self._stop.is_set():
            start = time.time()
            # Bias: thread 3 (the "victim") always yields to a random short
            # sleep before requesting, so it loses the race under contention —
            # a simple, honest way to reproduce priority-inversion-style
            # starvation without needing raw kernel scheduler access.
            if not self.fair_mode and idx == self.n_threads - 1:
                time.sleep(0.05)
            self.shared.acquire(name)
            waited = time.time() - start
            self.wait_log[name].append(round(waited, 3))
            self.service_count[name] += 1
            time.sleep(0.02)  # critical section
            self.shared.release(name)
            time.sleep(0.01 if self.fair_mode else 0.005)

    def start(self):
        self._threads = [
            threading.Thread(target=self._worker, args=(i,), daemon=True, name=f"T{i}")
            for i in range(self.n_threads)
        ]
        for t in self._threads:
            t.start()

    def stop(self):
        self._stop.set()

    def apply_fairness_fix(self):
        """Controlled intervention: switch to a fair acquisition policy
        (round-robin-ish backoff) — the measurable 'after' state."""
        self.fair_mode = True

    def report(self):
        result = {}
        for name, waits in self.wait_log.items():
            avg_wait = round(sum(waits) / len(waits), 3) if waits else 0
            max_wait = round(max(waits), 3) if waits else 0
            result[name] = {
                "service_count": self.service_count[name],
                "avg_wait_sec": avg_wait,
                "max_wait_sec": max_wait,
            }
        return result


if __name__ == "__main__":
    exp = StarvationExperiment()
    exp.start()
    time.sleep(4)
    print("BEFORE FIX:", exp.report())
    exp.apply_fairness_fix()
    exp.wait_log = {k: [] for k in exp.wait_log}
    exp.service_count = {k: 0 for k in exp.service_count}
    time.sleep(4)
    print("AFTER FIX:", exp.report())
    exp.stop()



class PriorityInversionExperiment:
    PRIORITY = {"H": 0, "M": 5, "L": 10}  # lower number = higher priority (nice-style)

    def __init__(self, mode="none", hold_time=1.5, m_duration=4.0):
        self.mode = mode  # "none" (no protocol) | "priority_inheritance"
        self.hold_time = hold_time
        self.m_duration = m_duration
        self.guard = LockGuard()
        for name, pri in self.PRIORITY.items():
            self.guard.register_thread(name, pri)
        if mode == "priority_inheritance":
            self.resource = PriorityInheritingLock("SharedResource", self.guard)
        else:
            self.resource = InstrumentedLock("SharedResource", self.guard)
        self.h_wait_time = None
        self._threads = []

    def _low(self):
        name = threading.current_thread().name
        self.resource.acquire(name)
        time.sleep(self.hold_time)
        self.resource.release(name)

    def _medium(self):
        end = time.time() + self.m_duration
        x = 0
        while time.time() < end:
            x = (x * 1234567 + 1) % 1_000_000_007

    def _high(self):
        name = threading.current_thread().name
        time.sleep(0.2)  # let L grab the resource first
        start = time.time()
        self.resource.acquire(name)
        self.h_wait_time = round(time.time() - start, 3)
        self.resource.release(name)

    def run(self):
        t_l = threading.Thread(target=self._low, name="L", daemon=True)
        t_m = threading.Thread(target=self._medium, name="M", daemon=True)
        t_h = threading.Thread(target=self._high, name="H", daemon=True)
        self._threads = [t_l, t_m, t_h]

        for t in self._threads:
            t.start()
        # native OS TIDs only exist after start() -- register them for real
        # setpriority() calls (verifiable via `ps -eLo tid,ni,comm`).
        for t in self._threads:
            self.guard.set_native_id(t.name, t.native_id)

        for t in self._threads:
            t.join(timeout=self.m_duration + self.hold_time + 3)

        return self.report()

    def report(self):
        return {
            "mode": self.mode,
            "h_wait_time_sec": self.h_wait_time,
            "hold_time_sec": self.hold_time,
            "m_duration_sec": self.m_duration,
            "priority_events": [e for e in self.guard.trace
                                 if e["event"] in ("PRIORITY_BOOST", "PRIORITY_RESTORE")],
            "snapshot": self.guard.snapshot(),
            "note": ("H's wait time is measured wall-clock. The size of the gap between "
                     "modes depends on real OS scheduling decisions (nice-value effects "
                     "on thread wake order), so it may vary run-to-run and by hardware -- "
                     "same class of hardware-dependency caveat as the CPU governor labs."),
        }


def compare_inversion_modes(hold_time=1.5, m_duration=4.0):
    """Research measurement: run the identical H/M/L scenario twice -- once
    with no protocol, once with priority inheritance -- and compare H's
    wait time. This is the concrete, quantified 'before/after' evidence for
    the fix, not just a claim that it works."""
    naive = PriorityInversionExperiment(mode="none", hold_time=hold_time, m_duration=m_duration).run()
    fixed = PriorityInversionExperiment(mode="priority_inheritance", hold_time=hold_time, m_duration=m_duration).run()
    improvement = None
    if naive["h_wait_time_sec"] is not None and fixed["h_wait_time_sec"] is not None:
        improvement = round(naive["h_wait_time_sec"] - fixed["h_wait_time_sec"], 3)
    return {
        "without_priority_inheritance": naive,
        "with_priority_inheritance": fixed,
        "h_wait_improvement_sec": improvement,
    }


if __name__ == "__main__":
    import json
    print(json.dumps(compare_inversion_modes(), indent=2))
